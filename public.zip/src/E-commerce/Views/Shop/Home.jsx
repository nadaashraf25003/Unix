export default function Home() {
  return <div>Content</div>;
}