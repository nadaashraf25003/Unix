export default function ShopLayout() {
  return <div>Contentmm</div>;
}