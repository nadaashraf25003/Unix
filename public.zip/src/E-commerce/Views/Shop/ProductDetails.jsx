export default function ProductDetails() {
  return <div>Content</div>;
}