export default function Register() {
  return <div>Content</div>;
}