export default function Login() {
  return <div>Content</div>;
}